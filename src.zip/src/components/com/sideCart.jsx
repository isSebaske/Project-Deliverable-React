import React from "react";

const SideCart = () => {
  return (
    <aside>
      <div>this is the side cart disply</div>
    </aside>
  );
};

export default SideCart;
