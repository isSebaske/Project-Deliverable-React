import React, { Component } from "react";
import Product from "./product";
import { getProducts } from "../data/ItemsData";
import _ from "lodash";
import { paginate } from "../utils/paginate";
import Pagination from "./com/pagination";
import SortGroups from "./com/sortGroups";
import SideCart from "./com/sideCart";

class ProductsList extends Component {
  state = {
    products: [],
    currentPage: 1,
    pageSize: 3,
    sortColumn: { path: "id", order: "asc" },
    sortGrups: ["id", "name", "description", "price", "quantity"],
    selectedSortGrup: "id",
    selectedItems: [],
  };

  componentDidMount() {
    const products = getProducts();
    this.setState({ products });
  }

  handleSort = (path) => {
    const sortColumn = { ...this.state.sortColumn };

    if (sortColumn.path === path)
      sortColumn.order = sortColumn.order === "asc" ? "desc" : "asc";
    else {
      sortColumn.path = path;
      sortColumn.order = "asc";
    }

    this.setState({ sortColumn, selectedSortGrup: path });
    console.log(path);
  };

  handlePageChange = (page) => {
    this.setState({ currentPage: page });
  };

  render() {
    const {
      currentPage,
      pageSize,
      sortColumn,
      products,
      selectedSortGrup,
      sortGrups,
    } = this.state;

    const sorted = _.orderBy(products, [sortColumn.path], [sortColumn.order]);

    const items = paginate(sorted, currentPage, pageSize);
    return (
      <div className=" row ">
        <div className="col-2 ps-5 pe-5">
          <SortGroups
            onSort={this.handleSort}
            sortGrups={sortGrups}
            selectedSortGrup={selectedSortGrup}
          />
          <div className=" d-flex p-3"></div>
        </div>
        {items.map((items) => (
          <div className=" col-3 p-5 mt-2">
            <Product
              product={items}
              addToCart={this.props.addToCart}
              key={items.id}
            />
          </div>
        ))}
        <div className=" offset-0 col-1">
          <SideCart />
        </div>
        <div className=" offset-6 col ps-5">
          <Pagination
            itemsCount={products.length}
            pageSize={pageSize}
            currentPage={currentPage}
            onPageChange={this.handlePageChange}
          />
        </div>
      </div>
    );
  }
}

export default ProductsList;
