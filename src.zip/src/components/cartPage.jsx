import React, { Component } from "react";
import { Link } from "react-router-dom/cjs/react-router-dom.min";

class Cart extends Component {
  state = {
    submit: false,
  };

  handleCheckout = () => {
    this.setState({ orderSubmitted: true });
  };

  render() {
    const { cart } = this.props;
    const { orderSubmitted } = this.state;
    return (
      <div>
        <h2>Your Cart</h2>
        {orderSubmitted ? (
          <div className="alert alert-success">
            Your order has been submitted successfully!
          </div>
        ) : (
          <div>
            {cart.length > 0 ? (
              cart.map((item, index) => (
                <div key={index} className=" m-2">
                  <p>Item ID: {item.id}</p>
                  <p>Price: ${item.price}</p>
                  <p>Quantity: {item.quantity}</p>
                </div>
              ))
            ) : (
              <p>Your cart is empty.</p>
            )}
            <button
              className="btn btn-primary shadow-sm m-3"
              onClick={this.handleCheckout}
            >
              Checkout
            </button>
          </div>
        )}
        <Link className="btn btn-outline-primary shadow-sm m-3" to="/">
          Back
        </Link>
      </div>
    );
  }
}

export default Cart;
