import React, { Component } from "react";
import ProductsList from "./components/productsList";
import { Route, Switch, Redirect } from "react-router-dom";
import Cart from "./components/cartPage";
import NavBar from "./components/navBar";
import Home from "./components/home";

class Store extends Component {
  state = {
    selectedItems: [],
  };

  updateSelectedItems = (items) => {
    this.setState({ selectedItems: items });
  };

  handleButtonClick = (id, price, quantity) => {
    const { selectedItems, products } = this.state;
    const product = products.find((product) => product.id === id);
    const selectedItem = selectedItems.find((item) => item.id === id);

    if (!product) {
      console.log("Product not found.");
      return;
    }

    const updatedQuantity = selectedItem
      ? selectedItem.quantity + quantity
      : quantity;

    if (updatedQuantity > product.quantity) {
      console.log("Not enough stock available.");
      return;
    }

    const newSelectedItems = selectedItem
      ? selectedItems.map((item) =>
          item.id === id ? { ...item, quantity: updatedQuantity } : item
        )
      : [...selectedItems, { id, price, quantity }];

    this.setState({ selectedItems: newSelectedItems }, () => {
      this.props.updateSelectedItems(newSelectedItems);
    });
  };

  render() {
    return (
      <div className="App">
        <NavBar />
        <div>
          <Switch>
            <Route path="/home" component={Home} />
            <Route
              path="/shop"
              render={(props) => (
                <ProductsList
                  {...props}
                  updateSelectedItems={this.updateSelectedItems}
                  selectedItems={this.state.selectedItems}
                  addToCart={this.handleButtonClick}
                />
              )}
            />
            <Route
              path="/cart"
              render={(props) => (
                <Cart {...props} cart={this.state.selectedItems} />
              )}
            />
            <Redirect from="/" exact to="/home" />
          </Switch>
        </div>
      </div>
    );
  }
}

export default Store;
